import React from "react";
import "../public/styles.css";

function Header() {
  return (
    <div className="header">
      <header>
        <h1>Keeper</h1>
      </header>
    </div>
  );
}

export default Header;
